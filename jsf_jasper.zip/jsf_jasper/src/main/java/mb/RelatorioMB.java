package mb;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRException;

import com.lowagie.text.DocumentException;

@ManagedBean(name = "RelatorioMB")
public class RelatorioMB {

	public String relatorio() {

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("copiaDocResp", true);
		
		List<String> relatorios = new ArrayList<String>();
		relatorios.add("checkList");
		this.gerarRelatorios(params, relatorios);

		return "";

	}

	public void gerarRelatorios(Map<String, Object> params,
			List<String> relatorios) {
		try {
			 ServletContext servletContext = (ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext();
			this.reports(params, relatorios, servletContext);
		} catch (JRException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	public static void reports(Map<String, Object> params,
			List<String> relatorios, ServletContext servletContext)
			throws JRException, IOException, DocumentException {

		// ServletContext servletContext = this.getContextoServlet();

		List<byte[]> filesInBytes = new ArrayList<byte[]>();

		Relatorios rel = new Relatorios();

		for (String relatorio : relatorios) {
			filesInBytes.add(rel.getPdfReportAsByteArray("P", params, relatorio
					+ ".jasper", null, servletContext));
		}

		byte[] files = null;
		files = Relatorios.mergeFilesInPages(filesInBytes);

		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext externalContext = context.getExternalContext();
		HttpServletResponse response = (HttpServletResponse) externalContext
				.getResponse();

		response.setContentType(null);
		response.setContentLength(files.length);

		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		Date date = new Date();
		String filename = "ficha_" + dateFormat.format(date) + ".pdf";

		response.addHeader("Content-Disposition", "filename=" + "\"" + filename
				+ "\"");

		ServletOutputStream responseStream = response.getOutputStream();
		responseStream.write(files, 0, files.length);

		if (responseStream != null) {
			responseStream.flush();
			responseStream.close();
		}

		context.renderResponse();
		context.responseComplete();

	}

}
