package iotmanager.modelo;

import java.io.Serializable;

public interface Entidade extends Serializable{
	
	Long getIdentificador();

}
