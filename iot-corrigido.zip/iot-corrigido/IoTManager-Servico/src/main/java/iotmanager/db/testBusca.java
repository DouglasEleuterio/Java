package iotmanager.db;

//import java.util.ArrayList;

//import iotmanager.db.*;
//import iotmanager.modelo.Fatos;

public class testBusca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FatosDB nha = new FatosDB();
		
		System.out.println(nha.listar());
	}

}
